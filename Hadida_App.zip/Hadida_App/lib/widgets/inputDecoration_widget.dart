import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../utils/colors.dart';

InputDecoration customInputDecoration({required String hintText, bool? isSuffix = true, Widget? prefix, IconData? suffixIcon }) {
return InputDecoration(
    contentPadding: const EdgeInsets.all(15),
    suffixIcon: isSuffix == true
        ?  Icon(suffixIcon ??
      Icons.arrow_forward_ios_sharp,
      color: AppColor.darkGreen,
      size: 20,
    ) : null,

    fillColor: AppColor.whiteColor,
    filled: true,
    prefixIcon: prefix,
    enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(
          color: AppColor.borderGray,
        )),
    focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide:
        BorderSide(
          color: AppColor.borderGray,
        )),
    hintText: hintText,

    hintStyle: GoogleFonts.manrope(
        textStyle: TextStyle(
            fontWeight:
            FontWeight.w500,
            fontSize: 15,
            color: AppColor.darkGray)
    )


);
}