import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import '../utils/colors.dart';

class ProfileContainer extends StatelessWidget {
  const ProfileContainer({super.key, required this.text, required this.image, this.isIcon = true, this.color});
final String text;
final String image;
final bool? isIcon;
final Color? color;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const  EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColor.borderGray),
      ),
      child: Row(children: [
        SvgPicture.asset(image),
        const SizedBox(width: 7,),
        TextWidget(text: text, fontweight: FontWeight.w500, fontsize: 16, color: color == null ? AppColor.darkGray : color,),
        const Spacer(),
        isIcon == true ? Icon(CupertinoIcons.chevron_forward, color: AppColor.lightGray,) : Container()
      ],),
    );
  }
}
