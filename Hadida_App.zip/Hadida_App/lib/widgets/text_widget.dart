import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';

class TextWidget extends StatelessWidget {
  final String text;
  final FontWeight fontweight;
  final double fontsize;
  final Color? color;
  final TextAlign talign;
  final int? maxLines;
  final bool? overflow;
  TextWidget({
    required this.text,
    required this.fontweight,
    required this.fontsize,
    this.color,
    this.talign = TextAlign.start,
    this.maxLines, this.overflow = true
  });

  @override
  Widget build(BuildContext context) {
    return Text(
        text,
        textAlign: talign,
        maxLines: maxLines,
        style:GoogleFonts.manrope(
            textStyle: TextStyle(
            color: color ?? AppColor.blackColor,
            fontWeight: fontweight,
            fontSize: fontsize,
            overflow: overflow == true ?  TextOverflow.ellipsis : TextOverflow.visible,
        )
        )
    );
  }
}
