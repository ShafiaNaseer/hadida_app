import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';

class TextButtonWidget extends StatelessWidget {
  final String text;
 final VoidCallback onTap;
  const TextButtonWidget({super.key,
    required this.text, required this.onTap,

  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Text(
          text,
          style: GoogleFonts.manrope(
            textStyle: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 12,
                color: AppColor.darkGreen),
          )
      ),
    );
  }
}
