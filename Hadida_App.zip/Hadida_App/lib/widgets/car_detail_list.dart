import 'package:flutter/material.dart';
import 'package:hadida_app/widgets/text_widget.dart';

import '../utils/colors.dart';

class CarListWidget extends StatelessWidget {
  const CarListWidget({super.key, required this.name, required this.value});
final String name;
final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextWidget(text: name, fontweight: FontWeight.w500, fontsize: 15, color: AppColor.lightTextColor,),
            TextWidget(text: value, fontweight: FontWeight.w600, fontsize: 15, color: AppColor.darkGray,),
          ],
        ),
        Divider(color: AppColor.borderGray, thickness: 1.5,),
        const SizedBox(height: 10,)
      ],
    );
  }
}
