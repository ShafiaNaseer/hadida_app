import 'package:another_xlider/another_xlider.dart';
import 'package:another_xlider/models/handler.dart';
import 'package:another_xlider/models/trackbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../utils/colors.dart';

class RangeSliderWidget extends StatelessWidget {
  final double lowerValue;
  final double upperValue;
  final Function(int, dynamic, dynamic)? onDragging;

  RangeSliderWidget({
    required this.lowerValue,
    required this.upperValue,
    required this.onDragging,
  });

  @override
  Widget build(BuildContext context) {
    return FlutterSlider(
      values: [lowerValue, upperValue],
      rangeSlider: true,
      max: 500,
      min: 0,
      onDragging: onDragging,
      handler: FlutterSliderHandler(
        child: SvgPicture.asset('asset/images/arrowsmall.svg'),
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColor.darkGreen),
          color: AppColor.whiteColor,
        ),
      ),
      handlerHeight: 30,
      handlerWidth: 30,
      rightHandler: FlutterSliderHandler(
        child: SvgPicture.asset('asset/images/arrowsmall.svg'),
        decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColor.darkGreen),
          color: AppColor.whiteColor,
        ),
      ),
      trackBar: FlutterSliderTrackBar(
        inactiveTrackBar: BoxDecoration(
          color: AppColor.darkGreen.withOpacity(0.2),
        ),
        activeTrackBar: BoxDecoration(
          color: AppColor.darkGreen,
        ),
      ),
    );
  }
}
