import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import 'package:readmore/readmore.dart';
import '../../utils/colors.dart';
import '../../widgets/car_detail_list.dart';
import '../../widgets/text_button_widget.dart';

class AdsDetailScreen extends StatefulWidget {
  const AdsDetailScreen({super.key});

  @override
  State<AdsDetailScreen> createState() => _AdsDetailScreenState();
}

class _AdsDetailScreenState extends State<AdsDetailScreen> {
  final CarouselController _carouselController = CarouselController();

  int _currentPage = 0;
  List<String> imageList = [
    'asset/images/carr.png',
    'asset/images/carr.png',
    'asset/images/carr.png',
  ];
  List<String> text = [
    'AC',
    'Sunroof',
    'ABS',
    'Power Steering',
    'Fog Lights',
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Stack(
                      children: [
                        SizedBox(
                            height: MediaQuery.sizeOf(context).height * 0.3,
                            width: MediaQuery.sizeOf(context).width,
                            child: CarouselSlider.builder(
                              carouselController: _carouselController,
                              itemCount: imageList.length,
                              options: CarouselOptions(
                                aspectRatio: 1,
                                enlargeCenterPage: true,
                                scrollDirection: Axis.horizontal,
                                //autoPlay: true,
                                onPageChanged: (index, reason) {
                                  // Update the current page index when the page changes
                                  setState(() {
                                    _currentPage = index;
                                  });
                                },
                              ),
                              itemBuilder: (ctx, index, realIdx) {
                                return SizedBox(
                                  child: Stack(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(20),
                                          image: DecorationImage(
                                            image: AssetImage(imageList[index]),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        width: double.infinity,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            )),
                        Positioned(
                          bottom: 10,
                          left: 0,
                          right: 0,
                          child: Center(
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.grey
                              ),
                              child: DotsIndicator(
                                dotsCount: imageList.length,
                                position: _currentPage,
                                decorator: DotsDecorator(
                                  color: AppColor.lightGray, // Inactive color
                                  activeColor: AppColor.whiteColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                          child: Row(children: [
                            InkWell(
                                onTap: (){
                                  Navigator.pop(context);
                                },
                                child: SvgPicture.asset('asset/images/back.svg')),
                            Spacer(),
                            SvgPicture.asset('asset/images/heart.svg'),
                            SizedBox(width: 5,),
                            SvgPicture.asset('asset/images/share.svg'),
                          ],),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget(text: 'Royal Royce Hybrid LX', fontweight: FontWeight.w700, fontsize: 18),
                        Row(
                          children: [
                            Icon(Icons.location_on_outlined, color: AppColor.lightGray,),
                            TextWidget(text: 'ROntario, Canada', fontweight: FontWeight.w500, fontsize: 12, color: AppColor.lightTextColor,),
                            Spacer(),
                            TextWidget(text: '24.05.2022', fontweight: FontWeight.w500, fontsize: 12, color: AppColor.lightTextColor,),
                          ],
                        ),
                        TextWidget(text: "\$35,650", fontweight: FontWeight.w700, fontsize: 18, color: AppColor.darkGreen,),

                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          child: SizedBox(
                            height: 86,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: 4,
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding: const EdgeInsets.only(right: 5, left: 5),
                                  child: Container(
                                    width: 94,
                                    height: 81,
                                    padding: const EdgeInsets.only(left: 10),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: AppColor.borderGray)
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Icon(Icons.access_time, color: AppColor.lightTextColor,),
                                        TextWidget(text: "2020", fontweight: FontWeight.w700, fontsize: 15, color: AppColor.darkGray,),
                                        TextWidget(text: "Year", fontweight: FontWeight.w400, fontsize: 12, color: AppColor.lightTextColor,),

                                      ],
                                    ),
                                  ),
                                );
                              },),
                          ),
                        ),

                        TextWidget(text: 'Car info', fontweight: FontWeight.w700, fontsize: 18),
                        const SizedBox(height: 15,),
                        const CarListWidget(name: 'Color', value: 'White'),
                        const CarListWidget(name: 'Model', value: 'RR Hybrid LX'),
                        const CarListWidget(name: 'Brand', value: 'Royal Royce'),
                        const CarListWidget(name: 'Transmission', value: 'Automatic'),
                        const CarListWidget(name: 'Insurance', value: 'Available'),
                        const CarListWidget(name: 'ID', value: '#45450840'),
                        const CarListWidget(name: 'Date', value: '03 Jan, 23 - 02:45'),
                        const CarListWidget(name: 'View Counts', value: '56'),
                        const CarListWidget(name: 'Engine', value: 'Diesel'),
                        const CarListWidget(name: 'Version', value: 'Megane 3'),
                        const CarListWidget(name: 'Year', value: '2016'),
                        const CarListWidget(name: 'Mileage', value: '117,000 km'),
                        TextWidget(text: 'Car Features', fontweight: FontWeight.w500, fontsize: 15, color: AppColor.lightTextColor,),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: SizedBox(
                            height: 35,
                            child: ListView.separated(
                              itemCount: text.length,
                              scrollDirection: Axis.horizontal,
                              separatorBuilder: (context, index) {
                                return const SizedBox(width: 10,);
                              },
                              itemBuilder: (context, index) {
                                return Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(color: AppColor.grayForFilter.withOpacity(0.3), borderRadius: BorderRadius.circular(20)),
                                  child: TextWidget(text: text[index], fontweight: FontWeight.w600, fontsize: 12),
                                );
                              },),
                          ),
                        ),
                        Divider(color: AppColor.borderGray, thickness: 1.5,),
                        const SizedBox(height: 10,),
                        TextWidget(text: 'About Seller ', fontweight: FontWeight.w700, fontsize: 18),
                        const SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 26,
                              child: Image.asset('asset/images/user_profile.png'),
                            ),
                            const SizedBox(width: 10,),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    TextWidget(text: 'Mark Henry', fontweight: FontWeight.w700, fontsize: 17, color: AppColor.darkGray,),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                                      child: SvgPicture.asset('asset/images/Subtract.svg'),
                                    ),
                                  ],
                                ),
                                TextWidget(text: 'Member since Sep 03, 2022', fontweight: FontWeight.w500, fontsize: 12, color: AppColor.lightTextColor,),
                                TextButtonWidget(text: 'See Profile', onTap: (){}),
                              ],)
                          ],
                        ),
                        const SizedBox(height: 10,),
                        Divider(color: AppColor.borderGray, thickness: 1.5,),
                        const SizedBox(height: 10,),
                        TextWidget(text: 'Description', fontweight: FontWeight.w700, fontsize: 18),
                        ReadMoreText(
                          'Royal Royce M4 is a 4 seater Coupe with the last recorded price of 1.36. It is...Royal Royce M4 is a 4 seater Coupe with the last recorded price of 1.36. It is...',
                          trimLines: 2,
                          lessStyle: GoogleFonts.manrope(
                              textStyle: TextStyle(
                                color: AppColor.darkGreen,
                                fontWeight: FontWeight.w600,
                                fontSize: 15,
                              )
                          ),
                          trimMode: TrimMode.Line,
                          trimCollapsedText: 'Read more',
                          trimExpandedText: 'Read less',
                          style: GoogleFonts.manrope(
                              textStyle: TextStyle(
                                color: AppColor.darkGray,
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                              )
                          ),
                          moreStyle: GoogleFonts.manrope(
                              textStyle: TextStyle(
                                color: AppColor.darkGreen,
                                fontWeight: FontWeight.w600,
                                fontSize: 15,
                              )
                          ),
                        ),
                        const SizedBox(height: 10,),
                        Divider(color: AppColor.borderGray, thickness: 1.5,),
                        const SizedBox(height: 10,),
                        TextWidget(text: 'Suggestions', fontweight: FontWeight.w700, fontsize: 18),
                        const SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          height: 260,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: 3,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return Container(
                                width: MediaQuery.sizeOf(context).width / 2,
                                margin: EdgeInsets.only(right: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: AppColor.lightGray),
                                    color: AppColor.whiteColor),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Stack(
                                      children: [
                                        const Image(
                                          image: AssetImage("asset/images/Rectangle 24019 (3).png"),
                                        ),
                                        Positioned(
                                          top: 5,
                                          right: 5,
                                          child: Container(
                                              padding: const EdgeInsets.all(5),
                                              decoration: BoxDecoration(
                                                color: AppColor.blackColor,
                                                shape: BoxShape.circle,
                                              ),
                                              child: const Icon(
                                                Icons.favorite_border,
                                                color: Colors.white,
                                              )),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(10),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          TextWidget(text: "Toyota Corolla 2011", fontweight: FontWeight.w600, fontsize: 13),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          TextWidget(text: "\$35,650", fontweight: FontWeight.w600, fontsize: 14, color: AppColor.darkGreen,),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          TextWidget(text: "Toronto, Canada", fontweight: FontWeight.w500, fontsize: 10, color: AppColor.lightTextColor,),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          const Divider(
                                            thickness: 1,
                                            height: 2,
                                            color: Color(0xffC8D1E5),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              TextWidget(text: "2019", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Container(
                                                height: 11,
                                                width: 2,
                                                color: const Color(0xffC8D1E5),
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              TextWidget(text: "15,350 km", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Container(
                                                height: 11,
                                                width: 2,
                                                color: const Color(0xffC8D1E5),
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              TextWidget(text: "Petrol", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),

                                            ],
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              );

                            },),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                      ],),
                  ),


                  Container(
                    width: MediaQuery.sizeOf(context).width,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white, // Background color
                      borderRadius: BorderRadius.circular(10.0), // Rounded corners
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5), // Shadow color
                          offset: Offset(0, -2), // Offset for the shadow (top shadow)
                          blurRadius: 5.0, // Spread of the shadow
                          spreadRadius: 2.0, // Expansion of the shadow
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          // height: 50,
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColor.darkGreen),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Center(
                              child: Row(
                                children: [
                                  SvgPicture.asset('asset/images/sms.svg'),
                                  const SizedBox(width: 5,),
                                  TextWidget(
                                    text: 'SMS',
                                    fontweight: FontWeight.w700,
                                    fontsize: 17,
                                    color: AppColor.darkGreen,
                                  ),
                                ],
                              )),
                        ),
                        Container(
                          // height: 50,
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColor.darkGreen),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Center(
                              child: Row(
                                children: [
                                  SvgPicture.asset('asset/images/call.svg'),
                                  const SizedBox(width: 5,),
                                  TextWidget(
                                    text: 'Call',
                                    fontweight: FontWeight.w700,
                                    fontsize: 17,
                                    color: AppColor.darkGreen,
                                  ),
                                ],
                              )),
                        ),
                        Container(
                          // height: 50,
                          padding: const EdgeInsets.all(15),

                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color(0xff1C9E7D),
                          ),
                          child: Center(
                            child: Row(
                              children: [
                                SvgPicture.asset('asset/images/chatnow.svg'),
                                const SizedBox(width: 5,),
                                Text('Apply',
                                    style: GoogleFonts.manrope(
                                      textStyle: const TextStyle(
                                          fontSize: 17,
                                          color: Color(0xffFFFFFF),
                                          fontWeight: FontWeight.w700),
                                    )),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )

                ],
              ),
            ),
            Positioned(
              bottom: 0,
              child: Container(
                width: MediaQuery.sizeOf(context).width,
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white, // Background color
                  borderRadius: BorderRadius.circular(10.0), // Rounded corners
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5), // Shadow color
                      offset: Offset(0, -2), // Offset for the shadow (top shadow)
                      blurRadius: 5.0, // Spread of the shadow
                      spreadRadius: 2.0, // Expansion of the shadow
                    ),
                  ],
                ),
                child: Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: AppColor.lightOrangeColor,
                  ),
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.star, color: AppColor.whiteColor,),
                        const SizedBox(width: 5,),
                        Text('Promote Ad - 10x faster',
                            style: GoogleFonts.manrope(
                              textStyle: const TextStyle(
                                  fontSize: 17,
                                  color: Color(0xffFFFFFF),
                                  fontWeight: FontWeight.w700),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
