import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hadida_app/Screens/profile/profile_setting.dart';
import 'package:hadida_app/utils/colors.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import '../../widgets/profile_container.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.darkGreen,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Positioned(
                  top: 40,
                  left: MediaQuery.of(context).size.width * 0.4,
                  child: TextWidget(
                    text: "My Profile",
                    fontsize: 17,
                    fontweight: FontWeight.w600,
                    color: AppColor.whiteColor,
                  ),
                ),
                const Align(
                    alignment: Alignment.topRight,
                    child: Image(image: AssetImage("asset/images/balss.png"))),
                Positioned(
                    top: 25,
                    right: 20,
                    child: Container(
                  height: 35,
                  width: 35,
                    decoration: BoxDecoration(color: AppColor.whiteColor, shape: BoxShape.circle),
                    child: IconButton(
                        padding: EdgeInsets.zero,
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const ProfileSetting()));
                        }, icon: Icon(Icons.settings, color: AppColor.darkGreen,))))
              ],
            ),
            SizedBox(height: 10),
            Stack(
fit: StackFit.loose,
              clipBehavior: Clip.none,

              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(21),
                      topLeft: Radius.circular(21),
                    ),
                    color: Colors.white,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Stack(
                      //   alignment: Alignment.center,
                      //   children: [
                      //     Center(
                      //       child: CircleAvatar(
                      //         radius: 50,
                      //         backgroundColor: AppColor.lightYellow,
                      //         backgroundImage: AssetImage('asset/images/profile/person.png'),
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      SizedBox(height: MediaQuery.sizeOf(context).height * 0.08),
                    Center(child: TextWidget(text: 'Mark Henry', fontweight: FontWeight.w700, fontsize: 18, color: AppColor.darkGray,)),
                      SizedBox(height: 5),
                      Center(child: TextWidget(text: 'abc123@gmail.com', fontweight: FontWeight.w500, fontsize: 12, color: AppColor.darkGray,)),
                    SizedBox(height: 25),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            width: 94,
                            height: 81,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColor.borderGray),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                TextWidget(
                                  text: "05",
                                  fontweight: FontWeight.w700,
                                  fontsize: 15,
                                  color: AppColor.darkGray,
                                ),
                                TextWidget(
                                  text: "Ads",
                                  fontweight: FontWeight.w400,
                                  fontsize: 12,
                                  color: AppColor.lightTextColor,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 94,
                            height: 81,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColor.borderGray),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                TextWidget(
                                  text: "18-25",
                                  fontweight: FontWeight.w700,
                                  fontsize: 15,
                                  color: AppColor.darkGray,
                                ),
                                TextWidget(
                                  text: "Follower",
                                  fontweight: FontWeight.w400,
                                  fontsize: 12,
                                  color: AppColor.lightTextColor,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 94,
                            height: 81,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: AppColor.borderGray),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                TextWidget(
                                  text: "2.5k",
                                  fontweight: FontWeight.w700,
                                  fontsize: 15,
                                  color: AppColor.darkGray,
                                ),
                                TextWidget(
                                  text: "Following",
                                  fontweight: FontWeight.w400,
                                  fontsize: 12,
                                  color: AppColor.lightTextColor,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Divider(
                        color: AppColor.borderGray,
                        thickness: 1.5,
                      ),
                      SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [

                          Expanded(
                            child: Container(
                              // height: 50,
                              padding: const EdgeInsets.all(15),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: const Color(0xff1C9E7D),
                              ),
                              child: Center(
                                child: Text('Follow',
                                    style: GoogleFonts.manrope(
                                      textStyle: const TextStyle(
                                          fontSize: 17,
                                          color: Color(0xffFFFFFF),
                                          fontWeight: FontWeight.w700),
                                    )),
                              ),
                            ),
                          ),
                          SizedBox(width: 10,),
                          Expanded( 
                            child: Container(
                              // height: 50,
                              padding: const EdgeInsets.all(15),
                              decoration: BoxDecoration(
                                border: Border.all(color: AppColor.darkGreen),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Center(
                                child: TextWidget(
                                  text: 'Message',
                                  fontweight: FontWeight.w700,
                                  fontsize: 17,
                                  color: AppColor.darkGreen,
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: 3,
                        itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Container(
                            margin: EdgeInsets.only(right: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: AppColor.lightGray),
                                color: AppColor.whiteColor),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Stack(
                                  fit: StackFit.loose,
                                  clipBehavior: Clip.none,
                                  children: [
                                    Image(image: AssetImage('asset/images/carrrrrr.png')),
                                    Positioned(
                                      top: 20,
                                      right: 0,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 3),
                                        decoration: BoxDecoration(
                                            color: AppColor.redColor,
                                            borderRadius: const BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                bottomLeft: Radius.circular(10))),
                                        child: TextWidget(text: "Ad Sold", fontweight: FontWeight.w600, fontsize: 10, color: AppColor.whiteColor,),
                                      ),
                                    ),
                                    Positioned(
                                      left: 10,
                                      bottom: -20,
                                      child: Container(
                                        padding: EdgeInsets.all(5),
                                        decoration: BoxDecoration(color: AppColor.whiteColor,
                                        borderRadius: BorderRadius.all(Radius.circular(20)),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.grey, // Change the color to your desired shadow color
                                              offset: Offset(0, 4), // Adjust the offset for the shadow
                                              blurRadius: 6, // Adjust the blur radius of the shadow
                                              spreadRadius: 0, // Adjust the spread radius of the shadow
                                            ),
                                          ],
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                          Image(image: AssetImage('asset/images/user_profile.png'), width: 30, height: 30, fit: BoxFit.fill,),
                                          SizedBox(width: 5,),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [

                                              Row(
                                                children: [
                                                  TextWidget(text: 'Mark Henry', fontweight: FontWeight.w700, fontsize: 11, color: AppColor.darkGray,),
                                                  Padding(
                                                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                                                    child: SvgPicture.asset('asset/images/Subtract.svg'),
                                                  ),
                                                ],
                                              ),
                                              TextWidget(text: 'Online', fontweight: FontWeight.w500, fontsize: 12, color: AppColor.primaryColor,),

                                            ],
                                          ),


                                        ],),
                                      ),
                                    )
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(height: 20,),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          TextWidget(text: "Royal Royce Hybrid LX", fontweight: FontWeight.w600, fontsize: 18),

                                          TextWidget(text: "\$35,650", fontweight: FontWeight.w800, fontsize: 18, color: AppColor.darkGreen,),
                                        ],
                                      ),

                                      const SizedBox(
                                        height: 10,
                                      ),
                                      TextWidget(text: "Toronto, Canada", fontweight: FontWeight.w500, fontsize: 10, color: AppColor.lightTextColor,),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Icon(Icons.access_time_sharp, size: 17, color: AppColor.lightTextColor,),
                                          const SizedBox(
                                            width: 5,
                                          ),
                                          TextWidget(text: "2020", fontweight: FontWeight.w500, fontsize: 14, color: AppColor.lightTextColor,),
                                          Spacer(),
                                          Container(
                                            height: 11,
                                            width: 2,
                                            color: const Color(0xffC8D1E5),
                                          ),
                                          Spacer(),
                                          Icon(Icons.access_time_sharp, size: 17, color: AppColor.lightTextColor,),
                                          const SizedBox(
                                            width: 5,
                                          ),
                                          TextWidget(text: "15,350 km", fontweight: FontWeight.w500, fontsize: 14, color: AppColor.lightTextColor,),
                                          Spacer(),
                                          Container(
                                            height: 11,
                                            width: 2,
                                            color: const Color(0xffC8D1E5),
                                          ),
                                          Spacer(),
                                          Icon(Icons.access_time_sharp, size: 17, color: AppColor.lightTextColor,),
                                          const SizedBox(
                                            width: 5,
                                          ),
                                          TextWidget(text: "Petrol", fontweight: FontWeight.w500, fontsize: 14, color: AppColor.lightTextColor,),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      const Divider(
                                        thickness: 1,
                                        height: 2,
                                        color: Color(0xffC8D1E5),
                                      ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          TextWidget(text: "Ontario, Canada", fontweight: FontWeight.w500, fontsize: 13, color: AppColor.lightTextColor,),
                                          TextWidget(text: "Listed 24.05.2022", fontweight: FontWeight.w500, fontsize: 13, color: AppColor.lightTextColor,),

                                        ],
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },)


                    ],
                  ),
                ),
                Positioned(
                  top: -MediaQuery.sizeOf(context).height * 0.065,
                  left: 0,
                  right: 0,
                  child: Container(
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey, // Change the color to your desired shadow color
                          offset: Offset(0, 4), // Adjust the offset for the shadow
                          blurRadius: 6, // Adjust the blur radius of the shadow
                          spreadRadius: 0, // Adjust the spread radius of the shadow
                        ),
                      ],
                    ),
                    child: CircleAvatar(
                      radius: 53,
                      backgroundColor: AppColor.whiteColor,
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: AppColor.lightYellow,
                        backgroundImage: AssetImage('asset/images/profile/person.png'),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
