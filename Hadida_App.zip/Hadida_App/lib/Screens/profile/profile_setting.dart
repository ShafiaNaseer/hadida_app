import 'package:flutter/material.dart';
import 'package:hadida_app/utils/colors.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import '../../widgets/profile_container.dart';

class ProfileSetting extends StatefulWidget {
  const ProfileSetting({Key? key});

  @override
  State<ProfileSetting> createState() => _ProfileSettingState();
}

class _ProfileSettingState extends State<ProfileSetting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.darkGreen,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                SizedBox(
                  height: MediaQuery.sizeOf(context).height * 0.135,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                          padding: const EdgeInsets.only(top: 50, bottom: 30),
                          onPressed: (){
                            Navigator.pop(context);
                          }, icon: Icon(Icons.keyboard_backspace, color: AppColor.whiteColor,)),
                      Spacer(flex: 1,),
                      Padding(
                        padding: const EdgeInsets.only(top: 50, bottom: 30, ),
                        child: TextWidget(text: 'Profile Settings', fontweight: FontWeight.w600, fontsize: 17, color: AppColor.whiteColor,),
                      ),
                      Spacer(flex: 2,)
                    ],
                  ),
                ),
                // Positioned(
                //   top: 40,
                //   left: MediaQuery.of(context).size.width * 0.4,
                //   child: TextWidget(
                //     text: "Profile Settings",
                //     fontsize: 17,
                //     fontweight: FontWeight.w600,
                //     color: AppColor.whiteColor,
                //   ),
                // ),
                const Align(
                    alignment: Alignment.topRight,
                    child: Image(image: AssetImage("asset/images/balss.png"))),
              ],
            ),
            SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(21),
                  topLeft: Radius.circular(21),
                ),
                color: Colors.white,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 10),
                  const ProfileContainer(text: "My Favorites",image: 'asset/images/profile/Bold_Heart.svg' ),

                  const ProfileContainer(text: "Edit Profile",image: 'asset/images/profile/Bold_Profile.svg'),
                  const ProfileContainer(text: "Address",image: 'asset/images/profile/Location-2.svg' ),
                  const ProfileContainer(text: "Notification Settings",image: 'asset/images/profile/Notification-2.svg' ),
                  const ProfileContainer(text: "Payments",image: 'asset/images/profile/Wallet-3.svg' ),
                  const ProfileContainer(text: "Language",image: 'asset/images/profile/language.svg' ),
                  const ProfileContainer(text: "Privacy Policy & Terms",image: 'asset/images/profile/lock.svg' ),
                  const ProfileContainer(text: "Help and Support",image: 'asset/images/profile/help.svg' ),
                  const ProfileContainer(text: "Refer a Friend",image: 'asset/images/profile/heart_friend.svg' ),
                  const ProfileContainer(text: "About Us",image: 'asset/images/profile/about.svg' ),
                   ProfileContainer(text: "Address",image: 'asset/images/profile/logout.svg', isIcon: false, color: AppColor.redColor,),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
