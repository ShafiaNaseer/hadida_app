import 'package:flutter/material.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/continue_button.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/step1_screen.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/step2_screen.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/step3_screen.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/step4_screen.dart';
import 'package:hadida_app/utils/colors.dart';
import '../../widgets/text_widget.dart';
import 'Stepper.dart';

class SellScreen extends StatefulWidget {
  SellScreen({Key? key}) : super(key: key);

  @override
  _SellScreenState createState() => _SellScreenState();
}

class _SellScreenState extends State<SellScreen> {
  int currentStep = 1;
  int stepLength = 4;
  late bool complete;

  next() {
    if (currentStep < 4) {
      goTo(currentStep + 1);
    }
  }

  back() {
    if (currentStep > 1) {
      goTo(currentStep - 1);
    }
  }

  goTo(int step) {
    setState(() => currentStep = step);
    if (currentStep > stepLength) {
      setState(() => complete = true);
    }
  }
  List<Widget> steps = [
    Container(child: Text('fjdhf'),),
    const Step1Data(),
    const Step2Data(),
    const Step3Data(),
    const Step4Screen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white, // Background color
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5), // Shadow color
                  offset: Offset(-2, 0), // Offset for the shadow (top shadow)
                  blurRadius: 5.0, // Spread of the shadow
                  spreadRadius: 2.0, // Expansion of the shadow
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.arrow_back),
                    Spacer(),
                    TextWidget(text: 'Sell Car', fontweight: FontWeight.w700, fontsize: 18),
                    Spacer(),
                  ],
                ),
                NumberStepper(
                  totalSteps: stepLength,
                  width: MediaQuery.of(context).size.width,
                  curStep: currentStep,
                  stepCompleteColor: AppColor.primaryColor,
                  currentStepColor: AppColor.whiteColor,
                  inactiveColor: Color(0xffbababa),
                  lineWidth: 8,
                ),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Expanded(
            child: ListView(
              children: [steps[currentStep]],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              child: ContinueButton(height: 60, text: 'Continue', onTap: (){
                next();
              }),
            ),
          ),
          // Expanded(
          //   child: ElevatedButton(
          //     onPressed: () {
          //       next();
          //     },
          //     child: Text(
          //       currentStep == stepLength ? 'Finish' : 'Next',
          //       style: TextStyle(color: Colors.white),
          //     ),
          //    // color: Colors.blue,
          //   ),
          // )
        ],
      ),
    );
  }
}