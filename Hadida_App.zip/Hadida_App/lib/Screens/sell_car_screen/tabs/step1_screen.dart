import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/continue_button.dart';
import '../../../utils/colors.dart';
import '../../../widgets/inputDecoration_widget.dart';
import '../../../widgets/text_widget.dart';
import '../sell_car.dart';

class Step1Data extends StatelessWidget {
  const Step1Data({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWidget(
            text: "Add title",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Enter title', isSuffix: false)),
          const SizedBox(
            height: 10,
          ),
          TextWidget(
            text: "Add Image of Car",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),


          DottedBorder(
            borderType: BorderType.RRect,
            dashPattern: [8, 4],
            radius: const Radius.circular(10),
            color: AppColor.lightTextColor,
            child: Container(
              width: MediaQuery.sizeOf(context).width,
              height: MediaQuery.sizeOf(context).height * 0.25,
              decoration: BoxDecoration(
                color: AppColor.lightGray,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(CupertinoIcons.photo, color: AppColor.darkGray,),
                      const SizedBox(width: 8,),
                      TextWidget(text: 'Upload Image', fontweight: FontWeight.w700, fontsize: 15, color: AppColor.darkGray,),
                    ],
                  ),
                  TextWidget(text: '(Recommended Size: 3:1)', fontweight: FontWeight.w500, fontsize: 11, color: AppColor.darkGray,),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),

          Container(
            // height: 50,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              border: Border.all(color: AppColor.darkGreen),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset('asset/images/profile/camera.svg'),
                    const SizedBox(width: 5,),
                    TextWidget(
                      text: 'Take a Photo',
                      fontweight: FontWeight.w700,
                      fontsize: 17,
                      color: AppColor.darkGreen,
                    ),
                  ],
                )),
          ),

          const SizedBox(
            height: 30,
          ),
          // ContinueButton(text: 'Continue', onTap: (){
          // }),
        ],
      ),
    );
  }
}
