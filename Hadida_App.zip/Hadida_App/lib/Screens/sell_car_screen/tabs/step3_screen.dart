import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/continue_button.dart';
import '../../../utils/colors.dart';
import '../../../widgets/inputDecoration_widget.dart';
import '../../../widgets/text_widget.dart';

class Step3Data extends StatefulWidget {
  const Step3Data({super.key});

  @override
  State<Step3Data> createState() => _Step3DataState();
}

class _Step3DataState extends State<Step3Data> {
  bool switchValue = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWidget(
            text: "Category",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            keyboardType: TextInputType.number,
              decoration: customInputDecoration(hintText: '\$10,0000.00', isSuffix: false)),
          const SizedBox(
            height: 15,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextWidget(
                text: "Firm on Price",
                fontweight: FontWeight.w600,
                fontsize: 16,
                color: AppColor.blackColor,
              ),

              CupertinoSwitch(
                // overrides the default green color of the track
                activeColor: AppColor.orangeColor,
                // color of the round icon, which moves from right to left
                thumbColor: AppColor.whiteColor,
                // when the switch is off
                trackColor: Colors.black12,
                // boolean variable value
                value: switchValue,
                // changes the state of the switch
                onChanged: (value) => setState(() {
                  switchValue = value;
                }),
              ),
            ],
          ),

        ],
      ),
    );
  }
}
