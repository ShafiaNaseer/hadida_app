import 'package:flutter/material.dart';

import '../../../utils/colors.dart';
import '../../../widgets/text_widget.dart';

class ContinueButton extends StatelessWidget {
  const ContinueButton({super.key, required this.text, required this.onTap, this.height});
final String text;
final VoidCallback onTap;
final double? height;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: height ,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: AppColor.darkGreen,
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Spacer(),
              TextWidget(text: text, fontweight: FontWeight.w800, fontsize: 17, color: AppColor.whiteColor,),
              Spacer(),
              Container(
                  padding: EdgeInsets.all(3),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: AppColor.blackColor.withOpacity(0.2)),
                  child: Icon(Icons.arrow_forward, color: AppColor.whiteColor,)),
              const SizedBox(width: 5,),
            ],
          ),
        ),
      ),
    );
  }
}
