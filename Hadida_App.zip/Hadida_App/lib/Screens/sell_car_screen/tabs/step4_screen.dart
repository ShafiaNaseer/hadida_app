import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Step4Screen extends StatefulWidget {
  const Step4Screen({super.key});

  @override
  State<Step4Screen> createState() => _Step4ScreenState();
}

class _Step4ScreenState extends State<Step4Screen> {

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(10),
                width: MediaQuery.sizeOf(context).width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color(0xffF2FFFC)
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                            "Promote your Ad",
                            style: GoogleFonts.manrope(
                              textStyle: TextStyle(
                                  fontWeight:
                                  FontWeight.w700,
                                  fontSize: 17,
                                  color:
                                  Color(0xff1C9E7D)),
                            )
                        ),
                        Spacer(),
                        Text(
                            "Skip",
                            style:GoogleFonts.manrope(
                              textStyle:  TextStyle(
                                  fontWeight:
                                  FontWeight.w700,
                                  fontSize: 15,
                                  color:
                                  Color(0xff485470)),
                            )
                        ),
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,children: [
                      Icon(Icons.done,color: Color(0xff99A7C7),size: 18,),
                      SizedBox(width: 10,),
                      Text(
                          "Sell 10x faster",
                          style:GoogleFonts.manrope(
                            textStyle:  TextStyle(
                                fontWeight:
                                FontWeight.w500,
                                fontSize: 13,
                                color:
                                Color(0xff485470)),
                          )
                      ),
                    ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,children: [
                      Icon(Icons.done,color: Color(0xff99A7C7),size: 18,),
                      SizedBox(width: 10,),
                      Text(
                          "Boost Your Ad to top Listings",
                          style: GoogleFonts.manrope(
                            textStyle:  TextStyle(
                                fontWeight:
                                FontWeight.w500,
                                fontSize: 13,
                                color:
                                Color(0xff485470)),
                          )
                      ),
                    ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,children: [
                      Icon(Icons.done,color: Color(0xff99A7C7),size: 18,),
                      SizedBox(width: 10,),
                      Text(
                          "Get noticed with a Promoted Tag",
                          style: GoogleFonts.manrope(
                            textStyle:  TextStyle(
                                fontWeight:
                                FontWeight.w500,
                                fontSize: 13,
                                color:
                                Color(0xff485470)),
                          )
                      ),
                    ],
                    ),
                    SizedBox(height: 15,),
                    Center(
                      child: Container(
                        width: MediaQuery.sizeOf(context).width*0.90,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,children: [
                          Row(
                            children: [
                              Container(
                                height:18,width: 18,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,border: Border.all(color: Color(0xffC8D1E5))
                                ),
                              ),
                              SizedBox(width: 10,),
                              Text(
                                  "Feature 1 Ad for 30 Days",
                                  style: GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),
                              Spacer(),
                              Text(
                                  "\$29.99",
                                  style:  GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),

                            ],
                          ),
                          SizedBox(height: 10,),
                          Text(
                              "Reach up to 20 times more buyers",
                              style: GoogleFonts.manrope(
                                textStyle: TextStyle(
                                    fontWeight:
                                    FontWeight.w500,
                                    fontSize: 12,
                                    color:
                                    Color(0xff7D8CAC)),
                              )
                          ),
                        ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15,),
                    Center(
                      child: Container(
                        width: MediaQuery.sizeOf(context).width*0.90,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,children: [
                          Row(
                            children: [
                              Container(
                                height:18,width: 18,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,border: Border.all(color: Color(0xffC8D1E5))
                                ),
                              ),
                              SizedBox(width: 10,),
                              Text(
                                  "Feature 1 Ad for 14 Days",
                                  style: GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),
                              Spacer(),
                              Text(
                                  "\$13.99",
                                  style: GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),

                            ],
                          ),
                          SizedBox(height: 10,),
                          Text(
                              "Reach up to 10 times more buyers",
                              style: GoogleFonts.manrope(
                                textStyle: TextStyle(
                                    fontWeight:
                                    FontWeight.w500,
                                    fontSize: 12,
                                    color:
                                    Color(0xff7D8CAC)),
                              )
                          ),
                        ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15,),
                    Center(
                      child: Container(
                        width: MediaQuery.sizeOf(context).width*0.90,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,children: [
                          Row(
                            children: [
                              Container(
                                height:18,width: 18,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,border: Border.all(color: Color(0xffC8D1E5))
                                ),
                              ),
                              SizedBox(width: 10,),
                              Text(
                                  "Feature 1 Ad for 07 Days",
                                  style:  GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),
                              Spacer(),
                              Text(
                                  "\$6.99",
                                  style:GoogleFonts.manrope(
                                    textStyle:  TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff1C9E7D)),
                                  )
                              ),

                            ],
                          ),
                          SizedBox(height: 10,),
                          Text(
                              "Reach up to 5 times more buyers",
                              style: GoogleFonts.manrope(
                                textStyle: TextStyle(
                                    fontWeight:
                                    FontWeight.w500,
                                    fontSize: 12,
                                    color:
                                    Color(0xff7D8CAC)),
                              )
                          ),
                        ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15,),
                    Center(
                      child: Container(
                        width: MediaQuery.sizeOf(context).width*0.90,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,children: [
                          Row(
                            children: [
                              Container(
                                height:18,width: 18,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,border: Border.all(color: Color(0xffC8D1E5))
                                ),
                              ),
                              SizedBox(width: 10,),
                              Text(
                                  "Feature 1 Ad for 1 Days",
                                  style: GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),
                              Spacer(),
                              Text(
                                  "\$0.99",
                                  style: GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff1C9E7D)),
                                  )
                              ),

                            ],
                          ),
                          SizedBox(height: 10,),
                          Text(
                              "Reach up to 3 times more buyers",
                              style: GoogleFonts.manrope(
                                textStyle: TextStyle(
                                    fontWeight:
                                    FontWeight.w500,
                                    fontSize: 12,
                                    color:
                                    Color(0xff7D8CAC)),
                              )
                          ),
                        ],
                        ),
                      ),
                    ),
                    SizedBox(height: 15,),
                    Center(
                      child: Container(
                        width: MediaQuery.sizeOf(context).width*0.90,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white,
                            border: Border.all(color: Color(0xff1C9E7D))
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,children: [
                              Text(
                                  "Create your Custom Package",
                                  style:  GoogleFonts.manrope(
                                    textStyle: TextStyle(
                                        fontWeight:
                                        FontWeight.w700,
                                        fontSize: 14,
                                        color:
                                        Color(0xff485470)),
                                  )
                              ),
                              Text(
                                  "Best for Business",
                                  style:GoogleFonts.manrope(
                                    textStyle:  TextStyle(
                                        fontWeight:
                                        FontWeight.w500,
                                        fontSize: 12,
                                        color:
                                        Color(0xff7D8CAC)),
                                  )
                              ),
                            ],
                            ),
                            Spacer(),
                            Icon(Icons.arrow_forward,color: Color(0xff1C9E7D),)
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 10,)


                  ],
                ),
              ),
              SizedBox(height: 10,),


            ],
          ),
        )


      ],
    );

  }
}
