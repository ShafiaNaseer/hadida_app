import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hadida_app/Screens/sell_car_screen/tabs/continue_button.dart';
import '../../../utils/colors.dart';
import '../../../widgets/inputDecoration_widget.dart';
import '../../../widgets/text_widget.dart';

class Step2Data extends StatelessWidget {
  const Step2Data({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWidget(
            text: "Category",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Select', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Sub Category",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Sedan', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Make",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Volkswagen', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Model",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Golf', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Year",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: '2020', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Variant",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Petrol', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Transmission",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Automatic', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Condition",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Select', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Mileage",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: '20/miles', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Color",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
              decoration: customInputDecoration(hintText: 'Black', suffixIcon: Icons.keyboard_arrow_down)),
          const SizedBox(
            height: 10,
          ), TextWidget(
            text: "Description",
            fontweight: FontWeight.w600,
            fontsize: 14,
            color: AppColor.grayForFilter,
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            maxLines: 5,
              decoration: customInputDecoration(
                  hintText: 'Add', isSuffix: false)),
          const SizedBox(
            height: 10,
          ),


          const SizedBox(
            height: 10,
          ),

        ],
      ),
    );
  }
}
