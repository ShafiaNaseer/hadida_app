import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hadida_app/Screens/ads_screen/ads_screen.dart';
import 'package:hadida_app/Screens/home_screen/home_screen.dart';
import 'package:hadida_app/utils/colors.dart';
import 'package:hadida_app/widgets/text_widget.dart';

import '../profile/user_profile.dart';
import '../sell_car_screen/sell_car.dart';


class BottomNavigationAppBar extends StatefulWidget {
  @override
  _BottomNavigationAppBarState createState() => _BottomNavigationAppBarState();
}

class _BottomNavigationAppBarState extends State<BottomNavigationAppBar> {
  int _currentIndex = 0;

  final List<Widget> _children = [
    const HomeScreen(),
    const AdsScreen(),
     SellScreen(),
    const SizedBox(),
    const ProfileScreen(),
  ];


  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        // backgroundColor: _currentIndex==0? const Color(0xff1C9E7D):_currentIndex==1?const Color(0xff1C9E7D):Colors.transparent,
        body: _children[_currentIndex],
        bottomNavigationBar: BottomAppBar(
          height: 70,
          child: Container(
            color: AppColor.whiteColor,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  BottomTab(onTap:(){
                    onTabTapped(0);
                  }, title: 'Home', icon: 'asset/images/bottomnav/Iconly Light Home.svg', titleIconColor: _currentIndex==0? AppColor.primaryColor : AppColor.grayForFilter ,),
                  BottomTab(onTap:(){
                    onTabTapped(1);
                  }, title: 'Ads', icon: 'asset/images/bottomnav/ads.svg' ,titleIconColor: _currentIndex==1? AppColor.primaryColor : AppColor.grayForFilter),
                  BottomTab(onTap:(){
                    onTabTapped(2);
                  }, title: 'Sell', icon: 'asset/images/bottomnav/Plus-4.svg' ,titleIconColor: _currentIndex==2? AppColor.primaryColor : AppColor.grayForFilter),
                  BottomTab(onTap:(){
                    onTabTapped(3);
                  }, title: 'Chat', icon: 'asset/images/bottomnav/chat.svg' ,titleIconColor: _currentIndex==3? AppColor.primaryColor : AppColor.grayForFilter),
                  BottomTab(onTap:(){
                    onTabTapped(4);
                  }, title: 'Profile', icon: 'asset/images/bottomnav/Profile.svg' ,titleIconColor: _currentIndex==4? AppColor.primaryColor : AppColor.grayForFilter),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class BottomTab extends StatelessWidget {
  final String title;
  final String icon;
  final VoidCallback onTap;
  final Color titleIconColor;
  const BottomTab({
    super.key,
    required this.title, required this.icon, required this.onTap, required this.titleIconColor,
  });


  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          SizedBox(height: 35,width: 25,
              child: SvgPicture.asset(icon.toString(), color: titleIconColor,),),
          const SizedBox(height: 4,),
          TextWidget(text: title.toString(), fontweight: FontWeight.w500, fontsize: 11, color: titleIconColor,)
        ],
      ),
    );
  }
}
