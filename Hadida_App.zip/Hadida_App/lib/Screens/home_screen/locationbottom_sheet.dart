import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hadida_app/utils/colors.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import '../../widgets/inputDecoration_widget.dart';
import '../../widgets/slider_widget.dart';

class LocationBottomSheet extends StatelessWidget {
  const LocationBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    double _lowerValue = 40;
    double _upperValue = 300;
    return StatefulBuilder(
      builder: (BuildContext context, void Function(void Function()) setState) {
        return Container(
        //  height: MediaQuery.sizeOf(context).height * 0.87,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: [
                      const Spacer(),
                      TextWidget(
                        text: "Your Location",
                        fontweight: FontWeight.w700,
                        fontsize: 18,
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.close,
                          color: AppColor.grayForFilter,
                          size: 30,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Divider(
                    height: 1,
                    thickness: 1,
                    color: Color(0xffC8D1E5),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  TextWidget(
                    text: "Location",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.darkGray,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(
                        hintText: 'New Yourk, USA',
                        prefix: Container(
                          padding: EdgeInsets.all(5),
                          margin: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColor.primaryColor.withOpacity(0.4)),
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColor.whiteColor),
                            child: Icon(
                              Icons.location_on_outlined,
                              color: AppColor.darkGreen,
                            ),
                          ),
                        ),
                      )),

                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextWidget(
                        text: "Location Radius",
                        fontweight: FontWeight.w600,
                        fontsize: 14,
                        color: AppColor.darkGray,
                      ),
                      TextWidget(
                        text: "0 - 850 km",
                        fontweight: FontWeight.w600,
                        fontsize: 14,
                        color: AppColor.darkGreen,
                      ),

                    ],
                  ),
                  RangeSliderWidget(
                    lowerValue: _lowerValue,
                    upperValue: _upperValue,
                    onDragging: (handlerIndex, lower, upper) {
                      setState(() {
                        _lowerValue = lower;
                        _upperValue = upper;
                      });
                    },
                  ),

                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
