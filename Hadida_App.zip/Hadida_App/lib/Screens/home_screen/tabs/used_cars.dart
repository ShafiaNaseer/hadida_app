import 'package:flutter/material.dart';
import 'package:hadida_app/Screens/ads_screen/ads_screen.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../utils/colors.dart';
import '../../../widgets/text_button_widget.dart';
import '../../../widgets/text_widget.dart';
import '../car_detail_screen.dart';
import '../see_all.dart';
class UsedCars extends StatefulWidget {
  const UsedCars({super.key});

  @override
  State<UsedCars> createState() => _UsedCarsState();
}

class _UsedCarsState extends State<UsedCars> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 10,
        ),
       Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(text: "Promoted ads" , fontweight: FontWeight.w700, fontsize: 17, color: AppColor.darkGray,),
            Spacer(),
            TextButtonWidget(text: 'See all',onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => SeeAllData(),));
            },),
            const SizedBox(
              width: 10,
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          height: 260,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 3,
            shrinkWrap: true,
            itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => DetailScreen(),));
              },
              child:
              Container(
                width: MediaQuery.sizeOf(context).width / 2,
                margin: EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColor.lightGray),
                    color: AppColor.whiteColor),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        const Image(
                          image: AssetImage("asset/images/Rectangle 24019.png"),
                        ),
                        Positioned(
                          top: 10,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                                color: AppColor.orangeColor,
                                borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(10),
                                    bottomRight: Radius.circular(10))),
                            child: TextWidget(text: "Promoted", fontweight: FontWeight.w600, fontsize: 10, color: AppColor.whiteColor,),
                          ),
                        ),
                        Positioned(
                          top: 5,
                          right: 5,
                          child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: AppColor.blackColor,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.favorite_border,
                                color: Colors.white,
                              )),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWidget(text: "Toyota Corolla 2011", fontweight: FontWeight.w600, fontsize: 13),
                          const SizedBox(
                            height: 5,
                          ),
                          TextWidget(text: "\$35,650", fontweight: FontWeight.w600, fontsize: 14, color: AppColor.darkGreen,),
                          const SizedBox(
                            height: 10,
                          ),
                          TextWidget(text: "Toronto, Canada", fontweight: FontWeight.w500, fontsize: 10, color: AppColor.lightTextColor,),
                          const SizedBox(
                            height: 10,
                          ),
                          const Divider(
                            thickness: 1,
                            height: 2,
                            color: Color(0xffC8D1E5),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextWidget(text: "2019", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                              const SizedBox(
                                width: 10,
                              ),
                              Container(
                                height: 11,
                                width: 2,
                                color: const Color(0xffC8D1E5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              TextWidget(text: "15,350 km", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                              const SizedBox(
                                width: 10,
                              ),
                              Container(
                                height: 11,
                                width: 2,
                                color: const Color(0xffC8D1E5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              TextWidget(text: "Petrol", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),

                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            );

          },),
        ),
        const SizedBox(
          width: 10,
        ),
        const SizedBox(
          height: 10,
        ),
        const Image(image: AssetImage("asset/images/Component 2.png")),
        const SizedBox(
          height: 10,
        ),
       Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(text: "Just like new", fontweight: FontWeight.w700, fontsize: 17, color: AppColor.darkGray,),
            Spacer(),
            TextButtonWidget(text: 'See all',onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => SeeAllData(),));

            },),
            SizedBox(width: 10)
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          height: 260,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 3,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => DetailScreen(),));
                },
                child: Container(
                  width: MediaQuery.sizeOf(context).width / 2,
                  margin: EdgeInsets.only(right: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColor.lightGray),
                      color: AppColor.whiteColor),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          const Image(
                            image: AssetImage("asset/images/Rectangle 24019 (3).png"),
                          ),
                          Positioned(
                            top: 5,
                            right: 5,
                            child: Container(
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  color: AppColor.blackColor,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.favorite_border,
                                  color: Colors.white,
                                )),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidget(text: "Toyota Corolla 2011", fontweight: FontWeight.w600, fontsize: 13),
                            const SizedBox(
                              height: 5,
                            ),
                            TextWidget(text: "\$35,650", fontweight: FontWeight.w600, fontsize: 14, color: AppColor.darkGreen,),
                            const SizedBox(
                              height: 10,
                            ),
                            TextWidget(text: "Toronto, Canada", fontweight: FontWeight.w500, fontsize: 10, color: AppColor.lightTextColor,),
                            const SizedBox(
                              height: 10,
                            ),
                            const Divider(
                              thickness: 1,
                              height: 2,
                              color: Color(0xffC8D1E5),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextWidget(text: "2019", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 11,
                                  width: 2,
                                  color: const Color(0xffC8D1E5),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                TextWidget(text: "15,350 km", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 11,
                                  width: 2,
                                  color: const Color(0xffC8D1E5),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                TextWidget(text: "Petrol", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );

            },),
        ),
        const SizedBox(
          height: 10,
        ),
      Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget(text: "Near you", fontweight: FontWeight.w700, fontsize: 17, color: AppColor.darkGray,),

            Spacer(),
            TextButtonWidget(text: 'See all',onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => SeeAllData(),));
            },),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          height: 260,
        //  height: MediaQuery.sizeOf(context).height / 2.99,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 3,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => DetailScreen(),));
                },
                child: Container(
                  width: MediaQuery.sizeOf(context).width / 2,
                  margin: EdgeInsets.only(right: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColor.lightGray),
                      color: AppColor.whiteColor),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          const Image(
                            image: AssetImage("asset/images/Rectangle 24019 (4).png"),
                          ),
                          Positioned(
                            top: 5,
                            right: 5,
                            child: Container(
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  color: AppColor.blackColor,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.favorite_border,
                                  color: Colors.white,
                                )),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWidget(text: "Toyota Corolla 2011", fontweight: FontWeight.w600, fontsize: 13),
                            const SizedBox(
                              height: 5,
                            ),
                            TextWidget(text: "\$35,650", fontweight: FontWeight.w600, fontsize: 14, color: AppColor.darkGreen,),
                            const SizedBox(
                              height: 10,
                            ),
                            TextWidget(text: "Toronto, Canada", fontweight: FontWeight.w500, fontsize: 10, color: AppColor.lightTextColor,),
                            const SizedBox(
                              height: 10,
                            ),
                            const Divider(
                              thickness: 1,
                              height: 2,
                              color: Color(0xffC8D1E5),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextWidget(text: "2019", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 11,
                                  width: 2,
                                  color: const Color(0xffC8D1E5),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                TextWidget(text: "15,350 km", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),
                                const SizedBox(
                                  width: 10,
                                ),
                                Container(
                                  height: 11,
                                  width: 2,
                                  color: const Color(0xffC8D1E5),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                TextWidget(text: "Petrol", fontweight: FontWeight.w500, fontsize: 11, color: AppColor.lightTextColor,),

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );

            },),
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }
}
