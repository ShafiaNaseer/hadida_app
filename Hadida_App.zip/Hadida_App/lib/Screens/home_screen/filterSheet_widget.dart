import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hadida_app/utils/colors.dart';
import 'package:hadida_app/widgets/text_widget.dart';
import '../../widgets/inputDecoration_widget.dart';
import '../../widgets/slider_widget.dart';

class CustomBottomSheet extends StatelessWidget {
  const CustomBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    double _lowerValue = 40;
    double _upperValue = 300;
    return StatefulBuilder(
      builder: (BuildContext context, void Function(void Function()) setState) {
        return Container(
          height: MediaQuery.sizeOf(context).height * 0.87,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: [
                      const Spacer(),
                      TextWidget(
                        text: "Filter",
                        fontweight: FontWeight.w700,
                        fontsize: 18,
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.close,
                          color: AppColor.grayForFilter,
                          size: 30,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const Divider(
                    height: 1,
                    thickness: 1,
                    color: Color(0xffC8D1E5),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: 'Vehicle Category',
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        height: 78,
                        width: MediaQuery.sizeOf(context).width * 0.20,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: const Color(0xffF8F9FB),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image(
                              color: AppColor.primaryColor,
                              height: 36,
                              image:
                                  const AssetImage("asset/images/Vector.png"),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            TextWidget(
                              text: 'Cabrio',
                              fontweight: FontWeight.w500,
                              fontsize: 12,
                              color: AppColor.darkGray,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        height: 78,
                       // width: MediaQuery.sizeOf(context).width * 0.20,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: AppColor.backgroundLightGray),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Image(
                              height: 36,
                              color: Color(0xff54D1B1),
                              image: AssetImage(
                                  "asset/images/car-black-side-view-pointing-left.png"),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            Text("Family",
                                style: GoogleFonts.manrope(
                                  textStyle: const TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      color: Color(0xff485470)),
                                )),
                          ],
                        ),
                      ),
                      Container(
                        height: 78,
                       // width: MediaQuery.sizeOf(context).width * 0.20,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffF8F9FB),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Image(
                              height: 36,
                              color: Color(0xff54D1B1),
                              image: AssetImage("asset/images/Group (1).png"),
                            ),
                            Text("Jeep-Cabrio",
                                style: GoogleFonts.manrope(
                                  textStyle: const TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 10,
                                      color: Color(0xff485470)),
                                )),
                          ],
                        ),
                      ),
                      Container(
                        height: 78,
                        width: MediaQuery.sizeOf(context).width * 0.20,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Color(0xffF8F9FB),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Image(
                              height: 36,
                              color: Color(0xff54D1B1),
                              image: AssetImage("asset/images/jeep.png"),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            Text("Jeep",
                                style: GoogleFonts.manrope(
                                  textStyle: const TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      color: Color(0xff485470)),
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Body Type",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      cursorColor: AppColor.darkGreen,
                      decoration: customInputDecoration(
                        hintText: 'Vehicles > SUV',
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Price Range",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: TextFormField(
                            decoration: customInputDecoration(
                                hintText: 'Min', isSuffix: false)),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: TextWidget(
                          text: "To",
                          fontweight: FontWeight.w500,
                          fontsize: 15,
                          color: AppColor.darkGray,
                        ),
                      ),
                      Expanded(
                        child: TextFormField(
                            decoration: customInputDecoration(
                                hintText: 'Max', isSuffix: false)),
                      ),
                    ],
                  ),
                  RangeSliderWidget(
                    lowerValue: _lowerValue,
                    upperValue: _upperValue,
                    onDragging: (handlerIndex, lower, upper) {
                      setState(() {
                        _lowerValue = lower;
                        _upperValue = upper;
                      });
                    },
                  ),
                  // FlutterSlider(
                  //   values: [_lowerValue, _upperValue],
                  //   rangeSlider: true,
                  //   max: 500,
                  //   min: 0,
                  //   onDragging: (handlerIndex, lowerValue, upperValue) {
                  //     _lowerValue = lowerValue;
                  //     _upperValue = upperValue;
                  //     setState(() {});
                  //   },
                  //
                  //   handler: FlutterSliderHandler(
                  //     child: SvgPicture.asset('asset/images/arrowsmall.svg'),
                  //     decoration: BoxDecoration(shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(10),border: Border.all(color: AppColor.darkGreen), color: AppColor.whiteColor)
                  //   ),
                  //   rightHandler: FlutterSliderHandler(
                  //       child: SvgPicture.asset('asset/images/arrowsmall.svg'),
                  //       decoration: BoxDecoration(shape: BoxShape.rectangle, borderRadius: BorderRadius.circular(10),border: Border.all(color: AppColor.darkGreen), color: AppColor.whiteColor)
                  //   ),
                  //
                  //   trackBar: FlutterSliderTrackBar(
                  //     inactiveTrackBar: BoxDecoration(
                  //       color: AppColor.darkGreen.withOpacity(0.2), // Change this to the desired color
                  //     ),
                  //     activeTrackBar: BoxDecoration(
                  //       color: AppColor.darkGreen, // Change this to the desired color
                  //     ),
                  //   ),
                  // ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Location",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(
                    hintText: 'New Yourk, USA',
                    prefix: Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColor.primaryColor.withOpacity(0.4)),
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: AppColor.whiteColor),
                        child: Icon(
                          Icons.location_on_outlined,
                          color: AppColor.darkGreen,
                        ),
                      ),
                    ),
                  )),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Sort by",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration:
                          customInputDecoration(hintText: 'Recent First')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Year",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: '2022')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Make",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration:
                          customInputDecoration(hintText: 'Royal Royce')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Mileage",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: '1200 miles')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Condition",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: 'New')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Style",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: 'Select')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Transmission",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: 'Automatic')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Drivetrain",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: 'Select')),
                  const SizedBox(
                    height: 10,
                  ),
                  TextWidget(
                    text: "Fuel Efficiency",
                    fontweight: FontWeight.w600,
                    fontsize: 14,
                    color: AppColor.grayForFilter,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                      decoration: customInputDecoration(hintText: '30 mpg')),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Container(
                        height: 50,
                        width: MediaQuery.sizeOf(context).width * 0.44,
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xffC8D1E5)),
                          borderRadius: BorderRadius.circular(15),
                          color: const Color(0xffFFFFFF),
                        ),
                        child: Center(
                            child: TextWidget(
                          text: 'Reset',
                          fontweight: FontWeight.w700,
                          fontsize: 17,
                          color: AppColor.darkGray,
                        )),
                      ),
                      Container(
                        height: 50,
                        width: MediaQuery.sizeOf(context).width * 0.44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: const Color(0xff1C9E7D),
                        ),
                        child: Center(
                          child: Text('Apply',
                              style: GoogleFonts.manrope(
                                textStyle: const TextStyle(
                                    fontSize: 17,
                                    color: Color(0xffFFFFFF),
                                    fontWeight: FontWeight.w700),
                              )),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
