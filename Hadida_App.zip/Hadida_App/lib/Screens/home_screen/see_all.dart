import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hadida_app/Screens/home_screen/seeall_categories.dart';

import '../../utils/colors.dart';
import '../../widgets/text_widget.dart';

class SeeAllData extends StatefulWidget {
  const SeeAllData({super.key});

  @override
  State<SeeAllData> createState() => _SeeAllDataState();
}

class _SeeAllDataState extends State<SeeAllData> {
  final List<String> tabText = [
    'Used Cars',
    'New Cars',
    'Bikes',
    'Autoparts',
  ];
  final List pages = [
    const Categories(),
    const SizedBox(),
    const SizedBox(),
    const SizedBox(),
  ];

  int _currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.darkGreen,
      body: Column(
        children: [
          SizedBox(
            height: MediaQuery.sizeOf(context).height * 0.135,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                    padding: const EdgeInsets.only(top: 50, bottom: 30),
                    onPressed: (){
                  Navigator.pop(context);
                }, icon: Icon(Icons.keyboard_backspace, color: AppColor.whiteColor,)),
                Spacer(flex: 1,),
                Padding(
                  padding: const EdgeInsets.only(top: 50, bottom: 30, ),
                  child: TextWidget(text: 'Promoted Offers', fontweight: FontWeight.w600, fontsize: 17, color: AppColor.whiteColor,),
                ),
                Spacer(flex: 2,)
              ],
            ),
          ),
          Expanded(
            child: Container(
              width: MediaQuery.sizeOf(context).width,
              height: MediaQuery.sizeOf(context).height,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(21),
                      topLeft: Radius.circular(21)),
                  color: Colors.white),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ...List.generate(
                              tabText.length,
                                  (index) => GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _currentIndex = index;
                                  });
                                },
                                child: Container(
                                  height: 37,
                                  margin: const EdgeInsets.only(right: 10),
                                  padding: const EdgeInsets.only(
                                      top: 9, right: 20, left: 20, bottom: 9),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: _currentIndex == index
                                            ? const Color(0xff1C9E7D)
                                            : Colors.transparent),
                                    borderRadius: BorderRadius.circular(20),
                                    color: _currentIndex == index
                                        ? Colors.white
                                        : const Color(0xffF1F4FB),
                                  ),
                                  child: Center(
                                    child: Text(
                                        tabText[index].toString(),
                                        style: GoogleFonts.manrope(
                                          textStyle: TextStyle(
                                              fontSize: 13,
                                              color: _currentIndex == index
                                                  ? const Color(0xff1C9E7D)
                                                  : const Color(0xff485470),
                                              fontWeight: FontWeight.w500),
                                        )
                                    ),
                                  ),
                                ),
                              )),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.sizeOf(context).height * 0.8,
                    child: pages[_currentIndex],
                  )

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
