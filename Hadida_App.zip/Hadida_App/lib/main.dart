import 'package:flutter/material.dart';
import 'package:hadida_app/Screens/ads_screen/ads_screen.dart';
import 'package:hadida_app/Screens/home_screen/home_screen.dart';
import 'package:hadida_app/Screens/sell_car_screen/sell_car_screen.dart';

import 'Screens/bottom_navbar/bottom_navBar.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Manrope',
      ),
      home: BottomNavigationAppBar());
  }
}

