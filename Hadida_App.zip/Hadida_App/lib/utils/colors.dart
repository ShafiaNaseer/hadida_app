import 'package:flutter/material.dart';

class AppColor {
  static Color primaryColor = const Color(0xff54D1B1);
  static Color blackColor = const Color(0xff212121);
  static Color whiteColor = const Color(0xffFFFFFF);
  static Color darkGreen = const Color(0xff1C9E7D);
  static Color orangeColor = const Color(0xffFF6600);
  static Color lightOrangeColor = const Color(0xffFF9040);
  static Color lightGray= const Color(0xffC8D1E5);
  static Color darkGray = const Color(0xff485470);
  static Color lightTextColor = const Color(0xff7D8CAC);
  static Color grayForFilter = const Color(0xff99A7C7);
  static Color backgroundLightGray = const Color(0xffF8F9FB);
  static Color borderGray = const Color(0xffE8E6EA);
  static Color lightYellow = const Color(0xffFFDBA5);
  static Color redColor = const Color(0xffE01D1D);
}